from feature_extraction.pluguins.DNS import AuxDNSFeatures
from feature_extraction.pluguins.FTP import AuxFTPFeatures
from feature_extraction.pluguins.ICMP import AuxICMPFeatures
from feature_extraction.pluguins.IP_layer import AuxPktMinMaxSizeFeatures, AuxRawIPPkt, AuxRawIPPktdirections
from feature_extraction.pluguins.statistics import AuxPktSizeFeatures, AuxSecBytesFeatures
from feature_extraction.pluguins.TCP_layer import AuxPktRetransmissionFeatures, AuxTCPFlagsFeatures, AuxTCPWindowMinMAx


udps=[AuxPktSizeFeatures(), AuxPktMinMaxSizeFeatures(), AuxTCPFlagsFeatures(), AuxTCPWindowMinMAx(),AuxICMPFeatures(),AuxDNSFeatures(), AuxFTPFeatures(), AuxPktRetransmissionFeatures(),AuxSecBytesFeatures(), AuxRawIPPkt()]

print(len(udps))