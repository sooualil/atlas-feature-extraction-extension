# dlnids
 NIDS feature extraction

## Extract features from raw datasets pcap files
%cd preprocess_datasets

specify the input folder of pcaps, the output folder of the results and the grounthruth in the /conf files 

%python datasetname.py
