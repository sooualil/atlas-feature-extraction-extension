import sys
sys.path.append("../")
from feature_extraction.pluguins.DNS import AuxDNSFeatures
from feature_extraction.pluguins.FTP import AuxFTPFeatures
from feature_extraction.pluguins.ICMP import AuxICMPFeatures
from feature_extraction.pluguins.IP_layer import AuxPktMinMaxSizeFeatures, AuxRawIPPkt#, AuxRawIPPktdirections
from feature_extraction.pluguins.statistics import AuxPktSizeFeatures, AuxSecBytesFeatures
from feature_extraction.pluguins.TCP_layer import AuxPktRetransmissionFeatures, AuxTCPFlagsFeatures, AuxTCPWindowMinMAx
from prep_utils import get_port_number, ensure_dir, create_dataframe
from nfstream import NFStreamer
import pandas as pd
import glob
import yaml

datasets = [
            'Benign',
            'Malware'
           ]

def extract_features(in_dir, out_dir):
    for exp in datasets:
        print(f"Exp : {exp}")
        files = glob.glob(f'{in_dir}/{exp}/*.pcap')
        for i in files:
            current_pcap_path = i
            file_name = i.split('/')[-1].split('.')[0]
            dump_path = f"{out_dir}/flow_pkts/"
            ensure_dir(dump_path)
            label = file_name if exp !='Benign' else 'Benign'
            current_out_csv_path = f"{out_dir}/temp/USTC-TFC2016_flow_{exp}_{file_name}.p"
            ensure_dir(f"{out_dir}/temp/")
            my_streamer = NFStreamer(source=current_pcap_path,
                            decode_tunnels=True,
                            bpf_filter=None,
                            promiscuous_mode=False,
                            snapshot_length=128,
                            idle_timeout=600,
                            active_timeout=3600,
                            accounting_mode=1,
                            n_dissections=20,
                            statistical_analysis=True,
                            splt_analysis=0,
                            udps=[AuxPktSizeFeatures(), AuxPktMinMaxSizeFeatures(), AuxTCPFlagsFeatures(), AuxTCPWindowMinMAx(),AuxICMPFeatures(),AuxDNSFeatures(), AuxFTPFeatures(), AuxPktRetransmissionFeatures(),AuxSecBytesFeatures(), AuxRawIPPkt()],
                            n_meters=0,
                            performance_report=0)
            df = create_dataframe(my_streamer, dump_path)
            df['attack_category'] = label
            df.to_pickle(current_out_csv_path, compression='infer', protocol=4)
            print(f"{current_pcap_path}: done")
    print(f"{exp}: Streaming done")
    print(f"{exp}: All done")
    print(f"___________________________________")


def load_full_dataframe(out_dir):
    files = glob.glob(f'{out_dir}/temp/*.p')
    dfs = []
    for f in files:
        df = pd.read_pickle(f)
        dfs.append(df)

    ustc = pd.concat(dfs)
    return ustc

if __name__ == "__main__":
    
    config_file = open('conf/ustc.yaml')
    properties = yaml.load(config_file, Loader=yaml.FullLoader)
    out_dir = properties['out_dir']
    in_dir = properties['in_dir']
    extract_features(in_dir, out_dir)
    ustc = load_full_dataframe(out_dir)
    ensure_dir(f'{out_dir}/flow_features/')
    ustc.to_pickle(f'{out_dir}/flow_features/USTC-TF2016_dataset.p', compression='infer', protocol=4)
    print(f"UNSW-NB15 dataset is saved into {out_dir}/flow_features/USTC-TF2016_dataset.p")

