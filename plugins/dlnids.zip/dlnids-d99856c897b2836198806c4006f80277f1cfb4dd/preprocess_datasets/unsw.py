import sys
sys.path.append("../")
from feature_extraction.pluguins.DNS import AuxDNSFeatures
from feature_extraction.pluguins.FTP import AuxFTPFeatures
from feature_extraction.pluguins.ICMP import AuxICMPFeatures
from feature_extraction.pluguins.IP_layer import AuxPktMinMaxSizeFeatures, AuxRawIPPkt#, AuxRawIPPktdirections
from feature_extraction.pluguins.statistics import AuxPktSizeFeatures, AuxSecBytesFeatures
from feature_extraction.pluguins.TCP_layer import AuxPktRetransmissionFeatures, AuxTCPFlagsFeatures, AuxTCPWindowMinMAx
from prep_utils import get_port_number, ensure_dir, create_dataframe
from nfstream import NFStreamer
import pandas as pd
import glob
import yaml


datasets = [
            'pcaps-17-2-2015',
            'pcaps-22-1-2015'
           ]

pcaps_lens = {
    'pcaps-17-2-2015': 27,
    'pcaps-22-1-2015': 53
}

def extract_features(in_dir, out_dir):
    for exp in datasets:
        print(f"Exp : {exp}")
        for i in range(pcaps_lens[exp]):
            current_pcap_path = f'{in_dir}{exp}/pcap{i+1}/{i+1}.pcap'
            print(current_pcap_path)
            dump_path = f"{out_dir}/flow_pkts/"
            ensure_dir(dump_path)
            current_out_csv_path = f"{out_dir}/temp/UNSW-NB15_singlef_{exp}_{i+1}.p"
            ensure_dir(f"{out_dir}/temp/")
            my_streamer = NFStreamer(source=current_pcap_path,
                                decode_tunnels=True,
                                bpf_filter=None,
                                promiscuous_mode=False,
                                snapshot_length=128,
                                idle_timeout=600,
                                active_timeout=3600,
                                accounting_mode=1,
                                n_dissections=20,
                                statistical_analysis=True,
                                splt_analysis=0,
                                udps=[AuxPktSizeFeatures(), AuxPktMinMaxSizeFeatures(), AuxTCPFlagsFeatures(), AuxTCPWindowMinMAx(),AuxICMPFeatures(),AuxDNSFeatures(), AuxFTPFeatures(), AuxPktRetransmissionFeatures(),AuxSecBytesFeatures(), AuxRawIPPkt()],
                                n_meters=0,
                                performance_report=0)
            df = create_dataframe(my_streamer, dump_path)
            df.to_pickle(current_out_csv_path, compression='infer', protocol=4)
            print(f"{current_pcap_path}: done")
        print(f"{exp}: Streaming done")
    print(f"{exp}: All done")
    print(f"___________________________________")


def load_full_dataframe(out_dir):
    files = glob.glob(f'{out_dir}/temp/*.p')
    dfs = []
    for f in files:
        df = pd.read_pickle(f)
        dfs.append(df)

    unsw_nb15 = pd.concat(dfs)
    return unsw_nb15

def load_ground_truth(csv_file):
    plist = ['pri-enc','ib', 'any'] 
    df_labels = pd.read_csv(csv_file)
    df_labels = df_labels.drop_duplicates(subset=['Start time', 'Last time', 'Attack category','Protocol', 'Source IP', 'Source Port', 'Destination IP',
        'Destination Port'], keep= 'first')
    df_labels['Start time'] = df_labels['Start time'] 
    df_labels['Last time'] = df_labels['Last time'] 
    df_labels['Source IP'] = df_labels['Source IP'].str.strip()
    df_labels['Destination IP'] = df_labels['Destination IP'].str.strip()

    df_labels = df_labels[~df_labels['Protocol'].isin(plist)]
    df_labels['Protocol'] = df_labels['Protocol'].apply(get_port_number)
    df_labels = df_labels.astype({'Protocol': float, 'Source Port': float, 'Destination Port':float, 'Start time': float, 'Last time': float})
    cols = ['start', 'end', 'attack_category', 'attack_subcategory', 'protocol', 'src_ip', 'src_port', 'dst_ip', 'dst_port', 'Attack Name','Attack Reference', "."]
    df_labels.columns = cols
    df_labels = df_labels[['start', 'end', 'attack_category', 'attack_subcategory', 'protocol', 'src_ip', 'src_port', 'dst_ip', 'dst_port']]
    return df_labels

def label_dataset(data, df_labels):
    li = list(range(144, 253)) 
    li_vals = data[data['protocol'].isin(li)]['protocol'].values
    data.loc[data['protocol'].isin(li), 'protocol'] = 144
    data['src_ip'] = data['src_ip'].str.strip()
    data['dst_ip'] = data['dst_ip'].str.strip()
    result = data.merge(df_labels, how='left', on =['protocol','src_ip', 'src_port', 'dst_ip', 'dst_port'])
    result = result.drop_duplicates(subset=data.columns.values)
    result.loc[result['protocol']==144, 'protocol'] = li_vals
    result = result.drop(['start', 'end', 'attack_subcategory'], axis= 1) 
    result['attack_category']  = result['attack_category'].fillna('Benign')
    result['attack_category'] = result['attack_category'].str.strip()
    result['attack_category'] = result['attack_category'].replace({'Backdoors':'Backdoor'})
    return result

 

if __name__ == "__main__":
    
    config_file = open('conf/unsw.yaml')
    properties = yaml.load(config_file, Loader=yaml.FullLoader)
    out_dir = properties['out_dir']
    in_dir = properties['in_dir']
    labels_csv_file = properties['labels_csv_file']
    ensure_dir(out_dir)
    extract_features(in_dir=in_dir, out_dir=out_dir)
    unsw_nb15 = load_full_dataframe(out_dir=out_dir)
    df_labels = load_ground_truth(labels_csv_file)
    unsw_nb15 = label_dataset(unsw_nb15, df_labels)

    ensure_dir(f'{out_dir}/flow_features/')
    unsw_nb15.to_pickle(f'{out_dir}/flow_features/UNSW-NB15_dataset.p', compression='infer', protocol=4)
    print(f"UNSW-NB15 dataset is saved into {out_dir}/flow_features/UNSW-NB15_dataset.p")




