import os
import pickle
import pandas as pd
from zipfile import ZipFile
import uuid
import numpy as np

import socket

def get_port_number(name):
    MISSING_PROTOCOL_MAPPINGS = {
    "nvp": 11,
    "sep": 33,
    "ospf": 89,
    "swipe": 53,
    "ipnip": 4,
    "argus": 13,
    "bbn-rcc": 10,
    "st2": 5,
    "dcn": 19,
    "mhrp": 48,
    "ipv6-no": 59,
    "micp": 95,
    "aes-sp3-d": 96,
    "ipx-n-ip": 111,
    "sm": 122,
    'sccopmce' : 128,
    "unas": 144,
    "zero":0,
    'any':'any'}
    try:
        proto_n =socket.getprotobyname(name)
    except:
        if name in MISSING_PROTOCOL_MAPPINGS.keys():
            proto_n = MISSING_PROTOCOL_MAPPINGS[name]
        else:
            proto_n = 200000
    return proto_n


def ensure_dir(file_path):
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)

def dump_pkts_bytes(path, filename, dic):
    if isinstance(dic, float) or dic is None :
        dic = {'1': np.zeros(20)}
    elif not isinstance(dic, dict):
        dic = {'1': np.zeros(20)}
    elif isinstance(dic, dict):
        if len(dic.keys()) == 0:
            dic = {'1': np.zeros(20)}
    pickle.dump(dic, open(path + filename, "wb" ) )

def create_dataframe(my_streamer, path):
    li = []
    df = None
    l = None
    i = 0
    cols = None
    zipObj = ZipFile(path+'pkts.zip', 'a', allowZip64 = True)
    for flow in my_streamer:
        filename = uuid.uuid4().hex +".p"
        if df is None:
            cols = flow.keys()
            df = pd.DataFrame(columns=cols)
            l = len(cols)
    
        if len(flow.values()) == l:
            ltemp = flow.values()
            dic = ltemp[-1]
            ltemp[-1] = filename
            dump_pkts_bytes(path, filename, dic)
            zipObj.write(path+filename)
            if os.path.exists(path+filename):
                os.remove(path+filename)
            else:
                print("The file does not exist")
            li.append(ltemp)
        else:
            i = i+1
            ltemp = flow.values()
            missing_cols = set(df.columns.values) - set(flow.keys())
            for col in missing_cols:
                idx = df.columns.get_loc(col)
                ltemp.insert(idx, np.nan)
            dic = ltemp[-1]
            ltemp[-1] = filename
            dump_pkts_bytes(path, filename, dic)
            zipObj.write(path+filename)
            if os.path.exists(path+filename):
                os.remove(path+filename)
            else:
                print("The file does not exist")
            li.append(ltemp)
    df_final = pd.DataFrame(li, columns=cols)
    print(f'number of mismatched cols and values {i}')
    zipObj.close()
    return df_final