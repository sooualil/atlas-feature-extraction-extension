import numpy as np



def chunks(l, n):
    """
    transform a list or array into chunks of lenght n

    Parameters
    ----------
    l: 1D ndarray, a list or array to devide into chunks
    n: int, is the size of each chunk

    Returns
    -------
    list of 1D ndarry of size n
    """
    li = []
    for i in range(0, len(l), n):
        li.append(l[i:i+n])
    return li

def padarray(A, size):
    """
    This method padd an arry into fixed size

    Parameters
    ----------
    A:  1D ndarray, input array
    size: int, the final size of the array  

    Returns
    -------
    1D ndarry of lenght size
    """
    t = size - len(A)
    return np.pad(A, pad_width=(0, t), mode='constant')

def flow_packets_bytes_to_images(dic, width= 224, height=224):
    """
    This method convert flow packets bytes to non-structured images 
    
    Parameters
    ----------
    dic: dictionnary of packets of a flow

    width: int, image width or the number of bytes to use from each flow 
            where packets are either trimmed or padded to the given size
    height: int, height of flow images
        

    Returns
    -------
    a list of images/ndarrays of shape (1, width, height)

    """
    images = []
    size = width * height
    big_arr = np.empty((0,))
    for key in list(dic.keys()):
        arr = dic[key]
        big_arr = np.append(big_arr, arr)
    if big_arr.shape[0] > size:
        limg = chunks(big_arr, size)
        images.append(limg[0].reshape((1, width, height)) / 255)
        limg.pop(0)
        for arr2 in limg:
            arr2 = padarray(arr2, size)
            images.append(arr2.reshape((1, width, height)) / 255)
    else:
        big_arr = padarray(big_arr, size)
        images.append(big_arr.reshape((1, width, height)) / 255)
              
    return images
        

def flow_packets_bytes_to_structured_images(dic, size=300, npkts=40):
    """
    This method convert flow packets bytes to structured images where each row represent a packets
    
        dic : dictionnary of packets of a flow

        size: image width or the number of bytes to use from each packet 
            packets are either trimmed or padded to the given size
        npkts: the number of packets per image
        
    Returns
    -------
    a list of images/ndarrays of shape (1, npkts, size)

    """
    images = []
    big_arr = np.empty((0,))
    for key in list(dic.keys()):
        arr = np.array(dic[key])
        if arr.shape[0] < size:
            arr = padarray(arr, size)
            big_arr = np.append(big_arr, arr)
        else:
            arr = arr[:size]
            big_arr = np.append(big_arr, arr)
    if big_arr.shape[0] > size * npkts:
        limg = chunks(big_arr, size * npkts)
        images.append(limg[0].reshape((1, npkts, size)) / 255)
        limg.pop(0)
        for arr2 in limg:
            arr2 = padarray(arr2, size * npkts)
            images.append(arr2.reshape((1, npkts, size)) / 255)
    else:
        big_arr = padarray(big_arr, size * npkts)
        images.append(big_arr.reshape((1, npkts, size)) / 255)
              
    return images
